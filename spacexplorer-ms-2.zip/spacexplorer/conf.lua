function love.conf(t)
  t.window.width = 380
  t.window.height = 640
  t.window.title = 'SpaceXplorer'
end
