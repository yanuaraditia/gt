-- explosion
-- particel system for asteroid explosion

local explosion = {}

-- write your code here

return explosion