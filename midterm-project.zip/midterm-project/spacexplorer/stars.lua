-- stars
-- for paralax effect

local stars = {}

-- write your code here

return stars