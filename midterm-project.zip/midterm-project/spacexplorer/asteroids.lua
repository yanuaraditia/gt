-- asteroids

-- create table
local asteroids = {}

-- write your code here

return asteroids