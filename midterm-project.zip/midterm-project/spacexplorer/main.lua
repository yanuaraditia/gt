---------------------------------------------------------------------------
-- SpaceXplorer
-- Author: (your name, your email)
-- 
-- main.lua
-- Main entry point
---------------------------------------------------------------------------

-- coordinates
-- write your code here

-- music and font
-- write your code here

-- references for game objects
-- write your code here

-- score and button
-- write your code here

-- circular collision detection
local function checkCollision()
  -- write your code here
end

-- show Head Up Display (HUD): score, hi-schore, and shield-bar
local function showHUD()
  -- write your code here
end

-- reset the game
local function resetGame()
  -- write your code here
end

function love.load()
  -- write your code here
end

function love.update(dt)
  -- write your code here
end

function love.draw()
  -- write your code here
end

function love.mousepressed(x, y, button)
  -- write your code here
end

function love.mousemoved(x, y)
  -- write your code here
end
