-- ship

local ship = {}

-- write your code here

return ship